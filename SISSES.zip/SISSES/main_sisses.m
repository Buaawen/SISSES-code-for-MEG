clear all
close all

load('lead.mat');
load('sim_source.mat');
load('cortex.mat');

SNR = 10;  sigma=5; alpha=0.1;tau=0.8;
%% Incoherent Sources
% %==================== White Gaussian Noise ============================= %
B = awgn(Gain*J,SNR,'measured');
B0=B;
StimTime=100;
%% Whiten measurements and lead field matrix
Bpre = B(:,1:StimTime);
Cov_n = (Bpre - repmat(mean(Bpre,2),1,StimTime)) * (Bpre - repmat(mean(Bpre,2),1,StimTime))'/(StimTime - 1);
rnkC_noise = rank(single(Cov_n));
variance = diag(Cov_n);
isPca = 1;
if isequal(Cov_n, diag(variance))
    isPca = 0;
end
[VV,D] = eig(Cov_n);
D = diag(D);
[D,I] = sort(D,'descend');
VV = VV(:,I);
if ~isPca
    D = 1./D;
    W = diag(sqrt(D)) * VV';
else
    D = 1 ./ D;
    D(rnkC_noise+1:end) = 0;
    W = diag(sqrt(D)) * VV';
    W = W(1:rnkC_noise,:);
end
% clear VV D I
L = W*Gain;
B = W*B;
[Dic1] = TBFSelection(B0,0,'threshold','Kaiser');

%%
[s_wen] = wen_sisses(B,L,cortex,Dic1',sigma,alpha,tau);
%%
cortex_wen.tri=cortex.Faces;
cortex_wen.pos=cortex.Vertices;

xx=abs(s_wen(:,155));
xxx=xx/max(xx);
figure;
ft_plot_mesh(cortex_wen,'vertexcolor',xxx,'colormap','jet');
