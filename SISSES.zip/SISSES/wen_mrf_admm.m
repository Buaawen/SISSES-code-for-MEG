function [res] = wen_mrf_admm(Phi, Y, V ,MM,rho,lambda,S11,x1,x2,W_a,W_v)

[N,M] = size(Phi);
[N,T] = size(Y);
[B,M] = size(V);
r1=rho(1);r2=rho(2);
lambda1=lambda(1);lambda2=lambda(2);
nn=size(x2,2);
b=Y;
D = Phi;
m=M;
% Default Parameter Values for Any Cases
MAX_ITERS     =100;   %2000    % maximum iterations
ABSTOL   = 1e-4;%绝对容忍度
RELTOL   = 1e-2;%相对容忍度
count=0;
S=x1*x2';
A=x1;
GB=x2;
VM=V*MM;

u=VM*A;
w=MM*A;


x=zeros(B,nn);
y=zeros(M,nn);


stduy_gb=1;
 prune=[0.01];
% Iteration

for k = 1 : MAX_ITERS
    count = count + 1;
    %=================== Compute new weights =================
    tic;
    S_old=S;
    counta=0;
    
    
    %
    % while 1
    %     counta=counta+1;
    A_old=A;
    q0=(D'*((b)*GB))+r1*(VM'*(u-x/r1))+r2*MM'*(w-y/r2);
    A=S11*q0;
    LA=D*A;
    
    uold=u;
    wold=w;
    
    uhat=VM*A;
    what=MM*A;
    u=soft_thresh(uhat+x/r1,W_v*(lambda1/r1));
    w=soft_thresh(what+y/r2,W_a*(lambda2/r2));
    x=x+r1*(uhat-u);
    y=y+r2*(what-w);

    
    
    S=A*GB';
    
    ds(count)=norm(S-S_old,'fro')/norm(S,'fro');

    D_s=S;
    D_GB=GB;
    D_A=A;

    D_u=u;
    D_w=w;
    D_x=x;
    D_y=y;

    toc;
    
    % ================= Check stopping conditions, etc. ==============
       % Stopping condition
    history.r2_norm(k)  = norm(VM*A-u);%主残差r2
    history.s2_norm(k)  = norm(-r1*VM'*(u - uold));%对偶残差s2
    history.r3_norm(k)  = norm(MM*A-w);%主残差r3
    history.s3_norm(k)  = norm(-r2*MM'*(w - wold));%对偶残差s2

%     
    history.eps_pri2(k) = sqrt(T)*ABSTOL + RELTOL*max(norm(VM*A), norm(-u));
    history.eps_dual2(k)= sqrt(T)*ABSTOL + RELTOL*norm(r1*VM'*x);

    history.eps_pri3(k) = sqrt(T)*ABSTOL + RELTOL*max(norm(MM*A), norm(-w));
    history.eps_dual3(k)= sqrt(T)*ABSTOL + RELTOL*norm(r2*MM'*y);
    
    if  1 %~QUIET
        fprintf('%3d\t%10.4f\t%10.4f\t%10.4f\t%10.4f\t%10.4f\t%10.4f\t%10.4f\t%10.4f\t%10.4f\t%10.4f\t%10.4f\t%10.4f\n',...
        k,  history.r2_norm(k), history.eps_pri2(k), ...
            history.r3_norm(k), history.eps_pri3(k), ...
            history.s2_norm(k), history.eps_dual2(k), ...
            history.s3_norm(k), history.eps_dual3(k));
    end

    if ( history.r2_norm(k) < history.eps_pri2(k) && ...
         history.s2_norm(k) < history.eps_dual2(k) && ...
         history.r3_norm(k) < history.eps_pri3(k) && ...
         history.s3_norm(k) < history.eps_dual3(k) )
         break;
    end
%     if ( ds(count) < 10^-3 )
%          break;
%     end
    
end

res.ds=ds;
res.GB=D_GB;
res.A=D_A;

res.D_ss=D_s;
res.D_u=D_u;
res.D_w=D_w;

res.D_x=D_x;
res.D_y=D_y;


% if (PRINT)
%     fprintf('\nWEN finished !\n');
% end
return;
end

function [soft_thresh] = soft_thresh( b,lambda )
    soft_thresh = sign(b).*max(abs(b) - lambda,0);
end

