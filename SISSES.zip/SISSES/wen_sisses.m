

function [S_est] = wen_sisses(B,L,cortex,GB,sigma,alpha,tau)
epsilon = 0.05;stop_crt    = 10^-2;
[C,M] = size(L);
V=-VariationEdge(cortex.VertConn);
[N,~] = size(V);


TBF=GB;
Num_TBF                = size(GB,2);
Num_alpha=length(alpha);
J_ini=zeros(M,Num_TBF);
max_weight_itr_num=9;


xnn=double(cortex.VertConn);
MM0=speye(15002)-tau*xnn./sum(xnn,2);
VM=V*MM0;
VTVM=VM'*VM;
MM=VTVM+MM0'*MM0;
invMM1=inv(full(MM));
D=L;
S11=invMM1-((invMM1*D')*inv(eye(C)+D*(invMM1*D')))*(D*invMM1);
%% Estimating Noise

for i_alpha = 1:Num_alpha
    alpha0 = alpha(i_alpha);
    x_0 = J_ini;
    stop_itr = 0;
    weight_it = 0;
    W = ones(M,Num_TBF);
    W_d = ones(N,Num_TBF);
    while (~stop_itr) 
        weight_it = weight_it + 1;
        if weight_it > max_weight_itr_num
            stop_itr = 1;
        end
       Num_TBF_old                = Num_TBF;
       [res] = wen_mrf_admm(L, B, V ,MM0,[1 1],sigma*[1 alpha0],S11,x_0,GB,W,W_d);
       
        x_old=x_0;
        x_0                          = res.A;
        Num_TBF= size(x_0,2);
        J=x_0;
        J_sol(:,:,weight_it,i_alpha) = J;
        
        J_n     = MM0*J;
        Ab_J    = squeeze(abs(J_n))+10^-20;
        Y_n     = VM*J;
        Ab_Y    = squeeze(abs(Y_n))+10^-20;
        
        W_old   = W;
        W_tr    = 1./(0 + Ab_J./(repmat(max(Ab_J),[M 1])) + (epsilon+10^-16) );
        W       = W_tr ; 
        W_d_old = W_d;
        W_d_tr  = 1./(0 + Ab_Y./(repmat(max(Ab_Y),[N 1]))+(epsilon+10^-16));
        W_d     = W_d_tr; 

        if (Num_TBF==Num_TBF_old)
            if (norm(W-W_old)/norm(W_old) < stop_crt && norm(W_d-W_d_old)/norm(W_d_old) < stop_crt)
                stop_itr = 1;
            end
            if (norm(x_old-x_0)/norm(x_old) < stop_crt)
                stop_itr = 1;
            end
        else
            GB=res.GB;
            
        end
    end
    
%     close all; 
end
if norm(res.D_w)==0
    S_est=res.D_ss;
else
    invmm0=inv(MM0);
    S_est=invmm0*res.D_w*TBF';
end
end
